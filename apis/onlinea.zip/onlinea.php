<?php
include("./libs.php");

// include("./url.php");
Header("content-type: text/json", true);
if (empty($_GET['type'])) {
    echo '{"success":"fail","code":404,"message":"缺少请求参数。","code":1}';
    return;
}
if (empty($_GET['value'])) {
    $value = "";
} else {
    $value = $_GET['value'];
}
$type = $_GET['type'];
if ($type == 'url')
    include("./url.php");

$offset = 0;
$limit = 30;
if (!empty($_GET['offset'])) {
    $offset = (int)$_GET['offset'];
}
if (!empty($_GET['limit'])) {
    $limit = (int)$_GET['limit'];
}
// $url = str_replace("\~", "%7E", $url);
$headers = "";
$value = urldecode($value);
if ($type != 'alarm') {
    if ($offset < 1) $offset = 1;
    if ($limit < 1) $offset = 10;
} else {
    if ($offset < 0) $offset = 0;
    if ($limit < 1) $offset = 10;
}

$page = (int)$offset - 1;
$html = "";
$format = "mp3";
if (!empty($_GET['format'])) {
    $format = $_GET['format'];
}
$result = json_decode('{}');
if (substr($value, 0, 6) == 'MUSIC_') {
    $value = substr($value, 6);
}
function searchSong($value, $limit, $offset)
{
    $value = urlencode($value);
    $url = "https://search.kuwo.cn/r.s?pn=$offset&rn=$limit&all=$value&ft=music&newsearch=1&alflac=1&itemset=web_2013&client=kt&cluster=0&vermerge=1&rformat=json&encoding=utf8&show_copyright_off=1&pcmp4=1&ver=mbox&plat=pc&vipver=MUSIC_9.2.0.0_W6&devid=11404450&newver=1&issubtitle=1&pcjson=1";
    $res = fetchURL($url);
    $output = json_decode('{"data":{"list":[]}}');

    //abslist
    if ($res != false) {
        $res = json_decode($res);
        $lists = $res->abslist;
        for ($i = 0; $i < count($lists); $i++) {
            $line = json_decode('{"id":0,"name":"Unknown","artist":"Unkown","releaseDate":null,"pic":null}');
            $line->name = $lists[$i]->NAME;
            $line->artist = $lists[$i]->ARTIST;
            $line->artistid = $lists[$i]->ARTISTID;
            $line->album = $lists[$i]->ALBUM;
            $line->albumid = $lists[$i]->ALBUMID;
            $line->pic = $lists[$i]->ALBUMID;
            $id = $lists[$i]->MUSICRID;
            if (substr($id, 0, 6) == 'MUSIC_') {
                $id = substr($id, 6);
            }
            $line->id = $id;
            $output->data->list[] = $line;
        }
    }
    $output->data->total = count($output->data->list) + 1;
    return $output;
}
function songinfo($id)
{
    $url = "https://www.kuwo.cn/newh5/singles/songinfoandlrc?musicId=$id&httpsStatus=1";
    $res = (fetchURL($url));
    $output = json_decode('{"data":{"info":{"id":0,"name":"Unknown","artist":"Unkown","releaseDate":null,"pic":null},"lrc":""}}');
    $output->data->info->id = $id;
    if ($res != false) {
        $res = json_decode($res);
        $lrctext = OBJtoTextLrc($res->data->lrclist);
        $output->data->lrc = $lrctext;
        $output->data->info->album = $res->data->songinfo->album;
        $output->data->info->artist = $res->data->songinfo->artist;
        $output->data->info->artistid = $res->data->songinfo->artistId;
        $output->data->info->albumid = $res->data->songinfo->albumId;
        $output->data->info->name = $res->data->songinfo->songName;
        $output->data->info->pic = $res->data->songinfo->pic;
    }
    return $output;
}
function songurl($id)
{
    $url = getMusicUrlUrl($id, $GLOBALS['format']);
    $return = fetchURL($url, false, "", 8, "curl/8.0.1", true);
    $a = strpos($return, "url=") + 4;
    $b =  strpos($return, "\r\n", $a);
    $length = $b - $a;
    $out = substr($return, $a, $length);
    return $out;
}

// echo $offsets;
switch ($type) {
    case 'info':
        $html = json_encode(songinfo($value));

        break;
    case 'url':
        $html = (songurl($value));

        break;
    case 'search':
        $html = json_encode(searchSong($value, $limit, $page));
        // saveId();
        break;
    default:
        echo '{"success":"fail","code":404,"message":"未知的参数","code":1}';
        http_response_code(200);
        return;
}
// saveId();

echo $html;
